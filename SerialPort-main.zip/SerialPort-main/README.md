# SerialPort
A library to communicate through a Serial port.

## Check out, build, and install

```
git clone https://github.com/vuquangtrong/SerialPort.git
cd SerialPort
make
sudo make install
```

## Example

Compile the example:

```
g++ example.cpp -lserial -o example
```

## MIT License

