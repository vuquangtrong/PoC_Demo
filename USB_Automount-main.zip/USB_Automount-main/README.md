# USB_Automount
Automatically mount a plugged in USB devices to Linux machines

## Check out and install

```
git clone https://github.com/vuquangtrong/USB_Automount.git
cd USB_Automount
./install
```

## Auto-mount point

Plugged-in USB will be mounted into `/media/<Label>` or `/media/<sdXy>`.
