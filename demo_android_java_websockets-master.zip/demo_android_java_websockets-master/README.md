# demo_android_java_websockets
Demonstrate how to run a Android websocket client using Java-Websocket

base on the server created in [demo_websocket_server_tkinter_gui](https://github.com/vuquangtrong/demo_websocket_server_tkinter_gui), there is an Android Client which connects to that server.

# Requirement
* [Java-WebSocket 1.3.9](https://github.com/TooTallNate/Java-WebSocket), *jar* file is included in [/libs](https://github.com/vuquangtrong/demo_android_java_websockets/tree/master/app/libs), but you can use latest source, please check the [/app/build.gradle](https://github.com/vuquangtrong/demo_android_java_websockets/blob/master/app/build.gradle)
* To run server, please read [demo_websocket_server_tkinter_gui](https://github.com/vuquangtrong/demo_websocket_server_tkinter_gui) or you can use any websocket, just remember to modify the host:port in Android project

Just simple as it is, cheerrrr! 
