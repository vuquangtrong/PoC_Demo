# websocket_server_gui
Demonstrate how to run a websocket server with tkinter gui

# Requirement
* python 3.6+
* websockets 6+ 
  `pip install websockets`
  or you cat look at the source code at https://github.com/aaugustin/websockets

# How to run
* run `test_websocket_server.py` first, you will see a GUI
* run `test_client.html` and you can run multiple instances of this web client
* click button on gui
* check the python log for more detail if you run .py in python shell

Just simple as it is, cheerrrrr!
